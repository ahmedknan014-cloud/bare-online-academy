import Link from 'next/link';
import { courses, pricing } from '@/lib/content';

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <section className="hero">
          <div className="container heroGrid">
            <div>
              <span className="pill light">🌍 Madal waxbarasho casri ah</span>
              <h1>Baro luqado. Dhis mustaqbalkaaga.</h1>
              <p>Bare Online Academy waxay siisaa bulshada Soomaaliyeed casharro LIVE ah, muuqaal la duubay, imtixaano, taageero macallin iyo qorshe waxbarasho oo cad.</p>
              <div className="actions"><a className="btn primary" href="#contact">Hadda iska diiwaangeli</a><a className="btn soft" href="#courses">Eeg koorsooyinka</a></div>
              <div className="trust"><span><b>5K+</b><br/>Arday</span><span><b>50+</b><br/>Macallimiin</span><span><b>20+</b><br/>Dal</span><span><b>4.9/5</b><br/>Qiimeyn</span></div>
            </div>
            <div className="heroCard"><div className="screen"><div className="screenTop"><i/><i/><i/></div><div className="courseLive"><div className="video">▶</div><h3>Cashar LIVE: Af-Turki A1</h3><p>Maanta: 19:00 • Macallin: Ahmed • 24 arday online</p><div className="miniRow"><div><strong>82%</strong>Horumar</div><div><strong>12</strong>Layliyo cusub</div></div></div></div></div>
          </div>
        </section>
        <section id="courses"><div className="container"><SectionHead tag="📚 Koorsooyinka" title="Waxbarasho luqad iyo dugsiyeed" text="Waxaan ku bilownay luqadaha ugu baahida badan, kadibna waxaan ku ballaarineynaa koorsooyin dugsiyeed ilaa heer lise."/><div className="grid3">{courses.map((course)=><article className={`card course ${course.soon ? 'soon' : ''}`} key={course.title}><span className="tag">{course.status}</span><div className="icon">{course.icon}</div><h3>{course.title}</h3><p>{course.description}</p></article>)}</div></div></section>
        <section id="platform" className="white"><div className="container split"><div><span className="pill">🚀 Platform</span><h2>Hal meel: cashar, video, imtixaan iyo taageero.</h2><p>MVP-ga koowaad wuxuu siinayaa ardayga dashboard, koorsooyin, videos, jadwal LIVE iyo lacag bixin online ah. Admin panel-na wuxuu maamuli karaa ardayda, macallimiinta iyo koorsooyinka.</p></div><div className="panel steps">{['Isdiiwaangeli — Dooro koorsada iyo heerkaaga.','Bixi lacagta — Stripe, PayPal; kadib EVC/Zaad/Salaam.','Bilow barashada — Video, LIVE, layliyo iyo taageero.'].map((s,i)=><div className="step" key={s}><span>{i+1}</span><b>{s}</b></div>)}</div></div></section>
        <section id="pricing"><div className="container"><SectionHead tag="💳 Qiimaha" title="Xirmooyin cad oo la fahmi karo" text="Bilow fudud, ka dibna u gudub LIVE iyo VIP marka aad rabto daryeel gaar ah."/><div className="grid3">{pricing.map((plan)=><article className={`card priceCard ${plan.featured ? 'featured' : ''}`} key={plan.name}><h3>{plan.name}</h3><p>{plan.text}</p><div className="price">${plan.price} <small>/ bishii</small></div><ul>{plan.features.map(f=><li key={f}>✓ {f}</li>)}</ul><a className={`btn ${plan.featured ? 'primary':'soft'}`} href="#contact">Dooro {plan.name}</a></article>)}</div></div></section>
        <section><div className="container cta"><div><h2>Diyaar ma u tahay inaad bilowdo?</h2><p>Buuxi foomka, kooxda Bare Online Academy ayaa kula soo xiriiri doonta si loo xaqiijiyo koorsada, heerka iyo jadwalka.</p></div><a className="btn soft" href="#contact">La xiriir hadda</a></div></section>
        <section id="contact" className="white"><div className="container split"><div><span className="pill">❓ FAQ</span><h2>Su'aalaha inta badan la isweydiiyo</h2><FAQ /></div><ContactForm /></div></section>
      </main>
      <Footer />
    </>
  );
}
function Header(){return <header><div className="container nav"><Link className="brand" href="/"><span className="logo">B</span><span>Bare Online<br/>Academy</span></Link><nav><a href="#courses">Koorsooyin</a><a href="#pricing">Qiimaha</a><Link href="/dashboard">Student</Link><Link href="/teacher">Teacher</Link><Link href="/admin">Admin</Link></nav><Link className="btn primary" href="/register">Isdiiwaangeli</Link></div></header>}
function SectionHead({tag,title,text}:{tag:string,title:string,text:string}){return <div className="sectionHead"><div><span className="pill">{tag}</span><h2>{title}</h2></div><p>{text}</p></div>}
function FAQ(){return <div className="faq"><details open><summary>Casharradu ma LIVE baa?</summary><p>Haa, Standard iyo VIP waxay leeyihiin casharro LIVE ah. Basic wuxuu leeyahay videos la duubay.</p></details><details><summary>Telefoon ma ku baran karaa?</summary><p>Haa. Website-ku waa mobile friendly, kadibna app gaar ah ayaa la sameyn karaa.</p></details><details><summary>Shahaado ma helayaa?</summary><p>Haa, marka koorsada iyo imtixaanka la dhammaystiro waxaa la siin karaa shahaado PDF ah.</p></details></div>}
function ContactForm(){return <div className="card"><span className="pill">📝 Kayıt</span><h2>Isdiiwaangeli</h2><form className="form"><input placeholder="Magacaaga"/><input placeholder="Email"/><input placeholder="WhatsApp / telefoon"/><select><option>Dooro koorso</option><option>Af-Turki</option><option>English</option><option>Carabi</option><option>Xisaab / Fen</option></select><textarea placeholder="Fariin kooban"/><button className="btn primary" type="button">Dir codsiga</button></form></div>}
function Footer(){return <footer><div className="container foot"><div><div className="brand"><span className="logo">B</span><span>Bare Online<br/>Academy</span></div><p>Baro Maanta, Hoggaami Berri. Madal waxbarasho oo casri ah, loogu talagalay bulshada Soomaaliyeed.</p></div><div><h4>Koorsooyin</h4><a>Af-Turki</a><a>English</a><a>Carabi</a><a>Jarmal</a></div><div><h4>Platform</h4><a>Student panel</a><a>Teacher panel</a><a>Admin panel</a><a>Payments</a></div><div><h4>La xiriir</h4><a>WhatsApp</a><a>info@bareonlineacademy.com</a><a>TikTok</a><a>YouTube</a></div></div><div className="container bottom">© 2026 Bare Online Academy. All rights reserved.</div></footer>}
