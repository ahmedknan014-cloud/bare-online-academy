import { NextResponse } from 'next/server';
import { cleanText, leadSchema } from '@/lib/security';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = leadSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const lead = {
    name: cleanText(parsed.data.name),
    email: parsed.data.email.toLowerCase(),
    phone: cleanText(parsed.data.phone),
    course: cleanText(parsed.data.course),
    message: cleanText(parsed.data.message ?? ''),
    createdAt: new Date().toISOString(),
  };

  // TODO: save to database or send to CRM/email provider.
  console.log('New lead', lead);
  return NextResponse.json({ ok: true });
}
