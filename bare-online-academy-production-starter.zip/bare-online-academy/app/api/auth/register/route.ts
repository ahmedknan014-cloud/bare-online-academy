import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { cleanText, hashPassword, registerSchema } from '@/lib/security';
import { setSessionCookie, signSession } from '@/lib/session';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const existing = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (existing) return NextResponse.json({ error: 'Email already registered' }, { status: 409 });

  const user = await prisma.user.create({
    data: {
      name: cleanText(parsed.data.name),
      email: parsed.data.email.toLowerCase(),
      password: await hashPassword(parsed.data.password),
      role: parsed.data.role,
    },
  });

  const token = signSession({ id: user.id, email: user.email, role: user.role, name: user.name });
  await setSessionCookie(token);
  return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
}
