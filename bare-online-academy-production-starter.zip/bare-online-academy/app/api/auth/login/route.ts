import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { loginSchema, verifyPassword } from '@/lib/security';
import { setSessionCookie, signSession } from '@/lib/session';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (!user) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });

  const valid = await verifyPassword(parsed.data.password, user.password);
  if (!valid) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });

  const token = signSession({ id: user.id, email: user.email, role: user.role, name: user.name });
  await setSessionCookie(token);
  return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
}
