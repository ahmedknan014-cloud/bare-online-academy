import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Bare Online Academy — Baro Maanta, Hoggaami Berri',
  description: 'Bare Online Academy: Af-Turki, English, Carabi iyo casharro dugsiyeed online ah.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="so"><body>{children}</body></html>;
}
