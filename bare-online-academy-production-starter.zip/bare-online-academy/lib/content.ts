export const courses = [
  { icon: '🇹🇷', title: 'Af-Turki', status: 'Aktif', description: 'A1 ilaa B1: naxwe, erayo, hadal, qoraal iyo casharro LIVE + duubis.' },
  { icon: '🇬🇧', title: 'English', status: 'Aktif', description: 'Beginner ilaa Intermediate: speaking club, grammar iyo shaqooyin joogto ah.' },
  { icon: '🇸🇦', title: 'Carabi', status: 'Aktif', description: "Akhris, qoraal, Qur'aan aasaasi ah iyo wada sheekeysi maalinle ah." },
  { icon: '🇩🇪', title: 'Jarmal', status: 'Dhawaan', soon: true, description: 'Barnaamij ku saleysan A1–B1, ku habboon dadka Yurub jooga.' },
  { icon: '🇫🇷', title: 'Faransiis', status: 'Dhawaan', soon: true, description: 'Aasaaska Faransiiska iyo tababar hadal oo fudud.' },
  { icon: '🔬', title: 'Dugsi & Lise', status: 'Taageero', description: 'Xisaab, Fen Bilimleri, Fiisigis, Kiimiko iyo Bayoolaji.' },
];

export const pricing = [
  { name: 'Basic', price: 29, text: 'Ku habboon qofka raba inuu iskiis u barto.', features: ['Videos la duubay', 'Group support', 'Layliyo aasaasi ah'] },
  { name: 'Standard', price: 59, featured: true, text: 'Casharro LIVE, macallin iyo imtixaan bil kasta.', features: ['Casharro LIVE', 'Video + homework', 'Imtixaan horumar', 'Shahaado'] },
  { name: 'VIP', price: 149, text: 'Birebir macallin iyo jadwal adiga kuu gaar ah.', features: ['1:1 Mentorship', 'Jadwal dabacsan', 'Warbixin horumar'] },
];
