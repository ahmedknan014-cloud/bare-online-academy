import bcrypt from 'bcryptjs';
import { z } from 'zod';

export const registerSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email().max(120),
  password: z.string().min(8).max(100),
  role: z.enum(['STUDENT', 'TEACHER']).optional().default('STUDENT'),
});

export const loginSchema = z.object({
  email: z.string().email().max(120),
  password: z.string().min(8).max(100),
});

export const leadSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email().max(120),
  phone: z.string().min(5).max(30),
  course: z.string().min(2).max(80),
  message: z.string().max(1000).optional(),
});

export function cleanText(value: string) {
  return value.replace(/[<>]/g, '').trim();
}

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}
