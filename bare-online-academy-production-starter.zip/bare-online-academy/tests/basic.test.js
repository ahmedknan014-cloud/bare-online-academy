const fs = require('fs');
const required = ['app/page.tsx','app/dashboard/page.tsx','app/admin/page.tsx','prisma/schema.prisma'];
for (const file of required) {
  if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
}
console.log('Bare Online Academy starter structure OK');
