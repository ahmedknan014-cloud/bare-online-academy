# Development Roadmap

## Phase 1: Landing MVP
- Somali-first landing page
- Course and pricing sections
- Contact lead form
- Deploy to Vercel

## Phase 2: Student MVP
- Auth
- Student dashboard
- Course enrollment
- Lesson/video pages
- Certificates

## Phase 3: Admin MVP
- Manage users
- Manage courses
- Manage lessons
- Track payments

## Phase 4: Payments
- Stripe/PayPal
- Manual Somali payment methods: EVC Plus, Zaad, Salaam Bank

## Phase 5: Scale
- Teacher panel
- Live classes
- AI tutor
- Mobile app
