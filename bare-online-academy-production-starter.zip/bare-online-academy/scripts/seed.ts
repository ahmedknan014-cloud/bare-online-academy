import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
async function main(){
  const course = await prisma.course.upsert({
    where: { id: 'turkish-a1' },
    update: {},
    create: { id:'turkish-a1', title:'Af-Turki A1', language:'Turkish', level:'A1', description:'Beginner Turkish for Somali speakers.', priceCents:5900, isPublished:true }
  });
  await prisma.lesson.createMany({ data:[
    { courseId: course.id, title:'Salaan iyo isbarasho', order:1, content:'Merhaba, nasılsın?' },
    { courseId: course.id, title:'Alfabe iyo dhawaaq', order:2, content:'Turkish alphabet basics.' }
  ], skipDuplicates:true });
}
main().finally(()=>prisma.$disconnect());
