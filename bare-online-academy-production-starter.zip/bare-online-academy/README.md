# Bare Online Academy — Production Starter

Somali-first EdTech platform starter built with Next.js, Prisma and PostgreSQL.

## What is included
- Premium landing page
- Student dashboard
- Teacher dashboard
- Admin dashboard
- Courses page
- Register and login pages
- Register/login API routes
- bcrypt password hashing
- HttpOnly + Secure-ready session cookie
- Zod input validation
- Security headers and HTTPS redirect middleware
- Prisma database schema for users, courses, lessons, quizzes, payments, certificates and leads
- Seed script
- Vercel deployment notes

## Local setup
```bash
npm install
cp .env.example .env
npm run prisma:generate
npm run dev
```

Open: http://localhost:3000

## Database setup
Use a PostgreSQL database, then set `DATABASE_URL` in `.env`.

```bash
npm run prisma:migrate
npm run prisma:seed
```

## Security commands
```bash
npm run security:audit
npm audit fix
```

## Useful commit messages
```bash
git add . && git commit -m "security: implement HTTPS redirection and enforce SSL"
git add . && git commit -m "fix(security): hash user passwords using bcrypt before saving"
git add . && git commit -m "chore(security): update vulnerable npm packages to latest versions"
git add . && git commit -m "fix(security): validate and sanitize user inputs"
git add . && git commit -m "security: enable HttpOnly and Secure flags for session cookies"
```

## Deploy to Vercel
1. Push this folder to GitHub.
2. Open Vercel and import the GitHub repo.
3. Add environment variables from `.env.example`.
4. Deploy.
5. Add your domain: `bareonlineacademy.com`.

Vercel automatically provides HTTPS/SSL.

## Next development steps
- Connect real PostgreSQL database.
- Make login/register forms call the API.
- Add role-based route protection.
- Add Stripe/PayPal checkout.
- Add manual payment review for EVC Plus, Zaad and Salaam Bank.
- Add lesson upload, video hosting and PDF materials.
